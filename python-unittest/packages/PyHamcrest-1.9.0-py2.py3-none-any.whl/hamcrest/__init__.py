from __future__ import absolute_import
from hamcrest.core import *
from hamcrest.library import *

__version__ = "1.9.0"
__author__ = "Chris Rose"
__copyright__ = "Copyright 2015 hamcrest.org"
__license__ = "BSD, see License.txt"
